document.addEventListener("DOMContentLoaded", function () {
    // Select relevant elements from the DOM
    const line = document.querySelector(".line");
    const text = document.querySelector(".text");
    const password_strength_box = document.querySelector(".password_strength_box");
    const password = document.querySelector(".password");

    // Function to update the password strength indicator
    function updateStrengthIndicator(strength, widthPercentage, color, message) {
        password_strength_box.style.display = "flex";
        line.style.width = widthPercentage;
        line.style.backgroundColor = color;
        text.style.color = color;
        text.innerHTML = message;
    }

    // Function to check the strength of the entered password
    function checkPasswordStrength() {
        const val = password.value;
        if (val.length === 0) {
            password_strength_box.style.display = "none";
            return;
        }
        // Check password strength criteria and update the strength indicator accordingly
        if (val.length >= 8 &&
            /[A-Z]/.test(val) &&
            /[a-z]/.test(val) &&
            /[0-9]/.test(val) &&
            /[!@#$%^&*]/.test(val)) {
            updateStrengthIndicator("Strong", "100%", "#2ccc2c", "Strong");
        } else if (val.length >= 7 &&
            /[A-Z]/.test(val) &&
            /[a-z]/.test(val) &&
            /[0-9]/.test(val)) {
            updateStrengthIndicator("Medium", "80%", "#e9ee30", "Medium");
        } else if (val.length >= 6 &&
            /[0-9]/.test(val)) {
            updateStrengthIndicator("Medium", "70%", "#e9ee30", "Medium");
        } else if (val.length >= 5 &&
            /[A-Z]/.test(val) &&
            /[a-z]/.test(val)) {
            updateStrengthIndicator("Medium", "50%", "#e9ee30", "Medium");
        } else if (val.length >= 4 &&
            /[!@#$%^&*]/.test(val)) {
            updateStrengthIndicator("Medium", "45%", "#e9ee30", "Medium");
        } else if (val.length >= 3) {
            updateStrengthIndicator("Weak", "20%", "red", "Weak");
        } else if (val.length >= 2) {
            updateStrengthIndicator("Weak", "10%", "red", "Weak");
        } else if (val.length >= 1) {
            updateStrengthIndicator("Weak", "5%", "red", "Weak");
        }
    }
    // Event listener for input in the password field to check password strength
    password.addEventListener("input", checkPasswordStrength);

    // Toggle password visibility
    const togglePassword = document.getElementById("togglePassword");
    const passwordInput = document.getElementById("password");
    const toggleIcon = document.getElementById("toggleIcon");

    // Event listener for toggling password visibility
    togglePassword.addEventListener("click", function () {
        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            toggleIcon.classList.remove("fa-eye");
            toggleIcon.classList.add("fa-eye-slash");
        } else {
            passwordInput.type = "password";
            toggleIcon.classList.remove("fa-eye-slash");
            toggleIcon.classList.add("fa-eye");
        }
    });

    // Generate CAPTCHA
    generateCaptcha();

    // Form validation
    document.getElementById('signupForm').addEventListener('submit', function (event) {
        const username = document.getElementById('username').value;
        const captchaInput = document.getElementById('captchaInput').value;
        const captcha = document.getElementById('captchaCanvas').getAttribute('data-captcha');

        const isValidUsername = /^[a-z]+$/.test(username);
        if (!isValidUsername) {
            alert('Username must contain only lowercase letters!');
            event.preventDefault();
            return;
        }

        if (captchaInput !== captcha) {
            alert('CAPTCHA does not match!');
            event.preventDefault();
            return;
        }
    });

    // Function to generate CAPTCHA
    function generateCaptcha() {
        const captchaBox = document.getElementById("captchaCanvas");
        const ctx = captchaBox.getContext("2d");
        const charsArray = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const lengthOtp = 6;
        let captcha = "";
        for (let i = 0; i < lengthOtp; i++) {
            const index = Math.floor(Math.random() * charsArray.length);
            captcha += charsArray[index];
        }

        // Save captcha value to be checked later
        captchaBox.setAttribute('data-captcha', captcha);

        // Draw CAPTCHA with distortion
        ctx.clearRect(0, 0, captchaBox.width, captchaBox.height);
        ctx.font = "40px Arial";
        ctx.fillStyle = "#000";
        const xPos = 20;
        const yPos = 50;
        for (let i = 0; i < captcha.length; i++) {
            const char = captcha[i];
            const angle = Math.random() * 0.4 - 0.2; // random angle between -0.2 and 0.2 radians
            ctx.save();
            ctx.translate(xPos + i * 30, yPos);
            ctx.rotate(angle);
            ctx.fillText(char, 0, 0);
            ctx.restore();
        }

        // Draw distortion lines
        for (let i = 0; i < 5; i++) {
            ctx.strokeStyle = "#000";
            ctx.beginPath();
            ctx.moveTo(Math.random() * captchaBox.width, Math.random() * captchaBox.height);
            ctx.lineTo(Math.random() * captchaBox.width, Math.random() * captchaBox.height);
            ctx.stroke();
        }
    }

    // Function to toggle privacy notice
    window.togglePrivacyNotice = function() {
        var privacyNotice = document.querySelector('.privacy-notice');
        privacyNotice.classList.toggle('active');
        
        // Toggle font size class
        var privacyText = document.querySelector('.privacy-notice ul');
        privacyText.classList.toggle('small-text');
    };
});


