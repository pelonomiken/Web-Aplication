package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.sql.DataSource;
import com.beans.User;

public class RegisterDBUtil {
	
private DataSource dataSource;
	
	public RegisterDBUtil(DataSource theDataSource){
		dataSource = theDataSource;
	}
	
	 public void registerUser(User user) throws Exception {
	        Connection conn = null;
	        PreparedStatement myStmt = null;
	        ResultSet myRs = null;

	        try {
	            conn = dataSource.getConnection();
	            String sql = "INSERT INTO user (Username, Password) VALUES (?, ?)";
	            myStmt = conn.prepareStatement(sql);

	            myStmt.setString(1, user.getUsername());
	            myStmt.setString(2, user.getPassword());

	            System.out.println("Executing SQL: " + myStmt.toString());
	            myStmt.execute();
	        } finally {
	            close(conn, myStmt, myRs);
	        }
	    }

	    private void close(Connection myConn, Statement myStmt, ResultSet myRs) {
	        try {
	            if (myConn != null) {
	                myConn.close();
	            }
	            if (myStmt != null) {
	                myStmt.close();
	            }
	            if (myRs != null) {
	                myRs.close();
	            }
	        } catch (Exception exec) {
	            exec.printStackTrace();
	        }
	    }
	}