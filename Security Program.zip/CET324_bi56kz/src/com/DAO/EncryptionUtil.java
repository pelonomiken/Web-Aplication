package com.DAO;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

public class EncryptionUtil {
	
	/**
	 * The EncryptionUtil class provides utility methods for encrypting and decrypting string literals
	 * using the AES (Advanced Encryption Standard) algorithm. It uses a predefined secret key 
	 * for both encryption and decryption, and the encrypted output is encoded in Base64 format.
	 * The class supports AES encryption with ECB (Electronic Codebook) mode and PKCS5 padding.
	 * It includes methods to:
	 * 1. Encrypt a plain text string and return the encrypted string in Base64 format.
	 * 2. Decrypt a Base64 encoded string and return the decrypted plain text string.
	 */

    private static final String SECRET_KEY = "MWxgjzuiCu123456"; // 16 bytes key

    public static String encrypt(String strToEncrypt) {
        try {
            SecretKeySpec secretKey = new SecretKeySpec(SECRET_KEY.getBytes("UTF-8"), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String decrypt(String strToDecrypt) {
        try {
            SecretKeySpec secretKey = new SecretKeySpec(SECRET_KEY.getBytes("UTF-8"), "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
