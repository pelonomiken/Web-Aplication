package com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.DAO.EncryptionUtil;
import com.DAO.RegisterDBUtil;
import com.beans.User;


/**
 * Servlet implementation class RegisterControllerServlet
 */
@WebServlet("/RegisterControllerServlet")
public class RegisterControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private RegisterDBUtil registerDBUtil;
    
	//define datasource/connection pool for resource injection
	@Resource(name = "jdbc/database1_use")	
	private DataSource dataSource;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	public void init() throws ServletException {
		super.init();
      //create our RegistrationDBUtil and parse in the connection pool
      		registerDBUtil = new RegisterDBUtil(dataSource);
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 try {
		        HttpSession session = request.getSession(false); // Do not create a new session if one doesn't exist

		        // Check if session exists and hasn't expired
		        if (session != null && !session.isNew()) {
		            addUser(request, response);
		        } else {
		            // Session has expired or doesn't exist, forward to sessionExpired.jsp
		            RequestDispatcher dispatcher = request.getRequestDispatcher("/sessionExpired.jsp");
		            dispatcher.forward(request, response);
		        }
		    } catch (Exception e) {
		        throw new ServletException(e);
		    }
		}
	
	 private void addUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		 /**
		  * This code snippet handles user registration by performing the following steps:
		  * 1. Retrieves the 'username' and 'password' parameters from the HTTP request.
		  * 2. Checks if either the 'username' or 'password' is null or empty. If so, 
		  * sets an error message and forwards the request back to 'index.jsp'.
		  * 3. Encrypts the password using the EncryptionUtil class. If encryption fails, 
		  * sets an error message and forwards the request back to 'index.jsp'.
		  * 4. Creates a new User object with the provided username and encrypted password,
		  * and registers the user using 'registerDBUtil'.
		  * 5. Manages the HTTP session:
		  *    - Retrieves the existing session, if available, or creates a new one.
		  *    - Sets the session timeout to 2 minutes.
		  *    - Stores the 'username' in the session.
		  * 6. Forwards the request to 'successRegistration.jsp' to indicate successful registration.
		  */
	        String username = request.getParameter("username");
	        String password = request.getParameter("password");

	        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
	            request.setAttribute("errorMessage", "Username and password cannot be null or empty");
	            RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
	            dispatcher.forward(request, response);
	            return;
	        }

	        String encryptedPassword = EncryptionUtil.encrypt(password);
	        if (encryptedPassword == null || encryptedPassword.isEmpty()) {
	            request.setAttribute("errorMessage", "Password encryption failed");
	            RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
	            dispatcher.forward(request, response);
	            return;
	        }

	      
	        User user = new User(username, encryptedPassword);
	        registerDBUtil.registerUser(user);

	        HttpSession session = request.getSession(false); // Get existing session if it exists
	        if (session == null) {
	            session = request.getSession(true); // Create new session if it doesn't exist
	            session.setMaxInactiveInterval(2 * 60); // Set session timeout to 2 minutes
	        }
	        session.setAttribute("username", username);

	        // Start session timeout listener
	        RequestDispatcher dispatcher = request.getRequestDispatcher("/successRegistration.jsp");
	        dispatcher.forward(request, response);
	    }
	 
	}